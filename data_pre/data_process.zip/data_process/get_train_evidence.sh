base_path=./gpt_v8.0.0
data_name=base_v_8_0_0_3
python generate_dongtai_chengprompt_0902_compare_juhe_evidence.py  ${base_path}/${data_name}.jsonl ${base_path}/${data_name}_32w_nofx_3_3500_llamatoken_prompt_id.json
python add_table.py ${base_path}/${data_name}_32w_nofx_3_3500_llamatoken_prompt_id.json ${base_path}/${data_name}_32w_nofx_3_3500_llamatoken_prompt_id_addtable.json
python get_fx_prompt.py ${base_path}/${data_name}_32w_nofx_3_3500_llamatoken_prompt_id_addtable.json ${base_path}/${data_name}_32w_codellama_3_3500_llamatoken_prompt_id_addtable2.json

