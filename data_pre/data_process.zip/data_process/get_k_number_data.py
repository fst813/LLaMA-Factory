import json

def check_file(f1,f2,number=10):
    with open(f1,encoding="utf-8") as f:
        #for line in f:
            data = json.load(f)
           
            for line in data[:number]:
                
                print(line["instruction"]+line["output"])
                
            save_data = data[:number]
            with open(f2,"w",encoding="utf-8") as fw:
                json.dump(save_data,fw,ensure_ascii=False,indent=4)

if __name__ == '__main__':
    import sys
    f1 = sys.argv[1]
    f2 = sys.argv[2]
    check_file(f1,f2)