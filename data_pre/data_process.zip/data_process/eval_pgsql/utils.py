import sqlite3
import pandas as pd
import json

def get_schema_and_data(db, num=2):
    """
    Get database's schema, which is a dict with table name as key
    and list of column names as value
    :param db: database path
    :return: schema dict
    """
    db_path = "data/database/{db}/{db}.sqlite".format(db=db)

    schema = {}
    data = {}
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # fetch table names
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = [str(table[0].lower()) for table in cursor.fetchall()]

    # fetch table info
    for table in tables:
        cursor.execute("PRAGMA table_info('{}')".format(table))
        result = cursor.fetchall()
        schema[table] = [str(col[1].lower()) + ":" + str(col[2].lower()) for col in
                         result]

        table_name_mappings = {str(col[1].lower()): str(col[1].lower()) + ":" + str(col[2].lower()) for col in
                               result}

        cursor.execute(f"select * from '{table}' limit 3;")
        result = cursor.fetchall()
        names = list(map(lambda x: table_name_mappings[x[0].lower()], cursor.description))
        result_list = []
        for row in result:
            result_list.append(dict(zip(names, row)))

        result = pd.DataFrame(result_list).head(n=num).to_markdown()
        data[table] = result

    cursor.close()
    cursor.connection.close()

    return schema, data
###得到数据库每个表的字段(字段类型)
def get_schema(db):
    """
    Get database's schema, which is a dict with table name as key
    and list of column names as value
    :param db: database path
    :return: schema dict
    """
    db_path = "database/{db}/{db}.sqlite".format(db=db)

    schema = {}
    data = {}
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # fetch table names
    
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = [str(table[0].lower()) for table in cursor.fetchall()]

    # fetch table info
    for table in tables:
        cursor.execute("PRAGMA table_info('{}')".format(table))
        result = cursor.fetchall()
        schema[table] = [str(col[1].lower()) + "(" + str(col[2].lower()) + ")" for col in result]

    cursor.close()
    cursor.connection.close()

    return schema

def get_schema_and_data_2(db, num=2):
    """
    Get database's schema, which is a dict with table name as key
    and list of column names as value
    :param db: database path
    :return: schema dict
    """
    db_path = "gptsql_dev/{db}/{db}.sqlite".format(db=db)

    schema = {}
    data = {}
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # fetch table names
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = [str(table[0].lower()) for table in cursor.fetchall()]

    # fetch table info
    for table in tables:
        cursor.execute("PRAGMA table_info('{}')".format(table))
        result = cursor.fetchall()
        schema[table] = {str(col[1].lower()) : str(col[2].lower()) for col in result}

        cursor.execute(f"select * from '{table}' limit {num};")
        result = cursor.fetchall()
        result_list = []
        for row in result:
            result_list.append(list(row))

        data[table] = result_list

    cursor.close()
    cursor.connection.close()

    return schema, data

def write_excel(df, filename):
    df=pd.DataFrame(df)
    writer=pd.ExcelWriter(filename)
    df.to_excel(writer,index=False)
    writer.save()
    writer.close()

def write_jsonl(result, filename):
    with open(filename,'w+',encoding='utf-8') as f:
        for line in result:
            line_str=json.dumps(line,ensure_ascii=False)
            f.writelines(line_str)
            f.write('\n')
        f.close()