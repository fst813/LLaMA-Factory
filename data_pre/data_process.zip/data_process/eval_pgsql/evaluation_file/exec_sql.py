# -*- coding: utf-8 -*-
"""
@Time ： 2024/1/29 14:30
@Auth ： fangsongtao
@File ：exec_sql.py
@IDE ：PyCharm
"""

import psycopg2


def exec_sql(sql, database):
    conn = psycopg2.connect(host='127.0.0.1', port=5432, user='postgres', password='123456', database=database)
    cursor = conn.cursor()
    cursor.execute(sql)
    result = cursor.fetchall()
    conn.close()
    cursor.close()
    return result

if __name__ == '__main__':
    sql = "SELECT \"日期\" , SUM ( \"进货销量\" ) AS \"进货销量\" FROM \"经销商进销存\" WHERE \"品类\" = '立白液' AND DATE_TRUNC ( 'month' , \"日期\" ) = '2024-02-01' GROUP BY \"日期\" ;"
    print(exec_sql(sql, 'chatbi_v2'))