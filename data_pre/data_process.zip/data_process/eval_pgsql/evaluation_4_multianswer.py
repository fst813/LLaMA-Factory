import pandas as pd
from evaluation_file.exec_eval import eval_exec_match
import os
from tqdm import tqdm
from sklearn.metrics import accuracy_score, f1_score, recall_score, precision_score
from utils import get_schema_and_data
import json
import numpy as np
import argparse
import sqlparse


def get_exec_result(db, p_str, golds):
    for g_str in golds:
        try:
            db = db.lower()
            exec_score = eval_exec_match(db=db, p_str=p_str, g_str=g_str, plug_value=False,
                                         keep_distinct=False, progress_bar_for_each_datapoint=False,
                                         have_xing_flag=True)
        except:
            exec_score = 0
        if exec_score == 1:
            break

    return 1 if exec_score else 0


def eval_model_old(df, column_name):
    result = {'全部结果': '', '拒识结果': ''}
    pred_generete = np.array(list(df[f'{column_name}_exec_eval']))
    result['全部结果'] = f'{np.sum(pred_generete == 1) * 1.0 / len(pred_generete)}'

    true_list = [1 if 'SELECT * FROM fake_table'.lower() in str(sql).lower() else 0 for sql in list(df['gold_sql'])]
    pre_list = [1 if 'SELECT * FROM fake_table'.lower() in str(sql).lower() else 0 for sql in list(df[column_name])]

    precision = precision_score(true_list, pre_list)
    accuracy_generate = accuracy_score(true_list, pre_list)
    recall = round(recall_score(true_list, pre_list), 3)
    F1 = round(f1_score(true_list, pre_list), 3)

    result['拒识结果'] = f'准确率：{accuracy_generate} 精确率：{precision} 召回率：{recall} F1值: {F1}'
    return result


def eval_model_old2(df, column_name):
    result = {'全部结果': '', '拒识结果': '', "sql结果": ''}

    # result_sql={'全部结果':'',"sql结果":''}
    pred_generete = np.array(list(df[f'{column_name}_exec_eval']))
    result['全部结果'] = f'{np.sum(pred_generete == 1) * 1.0 / len(pred_generete)}'

    true_list = [1 if 'SELECT * FROM fake_table'.lower() in str(sql).lower() else 0 for sql in list(df['gold_sql'])]
    pre_list = [1 if 'SELECT * FROM fake_table'.lower() in str(sql).lower() else 0 for sql in list(df[column_name])]
    precision = precision_score(true_list, pre_list)
    accuracy_generate = accuracy_score(true_list, pre_list)
    recall = round(recall_score(true_list, pre_list), 3)

    F1 = round(f1_score(true_list, pre_list), 3)

    result['拒识结果'] = f'准确率：{accuracy_generate} 精确率：{precision} 召回率：{recall} F1值: {F1}'

    true_list = [0 if 'SELECT * FROM fake_table'.lower() in str(sql).lower() else 1 for sql in list(df['gold_sql'])]
    pre_list = [0 if 'SELECT * FROM fake_table'.lower() in str(sql).lower() else 1 for sql in list(df[column_name])]
    precision = precision_score(true_list, pre_list)
    accuracy_generate = accuracy_score(true_list, pre_list)
    recall = round(recall_score(true_list, pre_list), 3)
    F1 = round(f1_score(true_list, pre_list), 3)
    result['sql结果'] = f'准确率：{accuracy_generate} 精确率：{precision} 召回率：{recall} F1值: {F1}'

    return result


def eval_model(df, column_name):
    result = {'全部结果': '', '拒识结果': '', "sql结果": ''}

    # result_sql={'全部结果':'',"sql结果":''}
    pred_generete = np.array(list(df[f'{column_name}_exec_eval']))
    result['全部结果'] = f'{round(np.sum(pred_generete == 1) * 1.0 / len(pred_generete), 3)}'

    true_list = [1 if 'SELECT * FROM fake_table'.lower() in str(sql).lower() else 0 for sql in list(df['gold_sql'])]
    pre_list = [1 if 'SELECT * FROM fake_table'.lower() in str(sql).lower() else 0 for sql in list(df[column_name])]
    precision = round(precision_score(true_list, pre_list), 3)
    # accuracy_generate = accuracy_score(true_list, pre_list)
    recall = round(recall_score(true_list, pre_list), 3)

    F1 = round(f1_score(true_list, pre_list), 3)

    result['拒识结果'] = f'精确率：{precision} 召回率：{recall} F1值: {F1}'

    pre_list = []
    for _, row in df.iterrows():
        if 'SELECT * FROM fake_table'.lower() in row['gold_sql'].lower():
            continue
        else:
            pre_list.append(row[f'{column_name}_exec_eval'])

    result['sql结果'] = f'准确率：{round(np.sum(np.array(pre_list) == 1) * 1.0 / len(pre_list), 3)}'
    return result


def post_process(df, sql_column):
    df = df.replace('&#10;', ' ', regex=True)
    #df[sql_column].fillna('SELECT * FROM fake_table;', inplace=True)
    df.fillna({"sql_column":"SELECT * FROM fake_table;"}, inplace=True)
    df['gold_sql'] = df['gold_sql'].apply(
        lambda x: x.replace('合同额预测2', '合同额预测').replace('合同明细2', '合同明细'))
    df[sql_column] = df[sql_column].apply(
        lambda x: x.replace('合同额预测2', '合同额预测').replace('合同明细2', '合同明细'))
    df = df.apply(lambda x: process_current_date(x, 'gold_sql'), axis=1)
    df['gold_sql'] = df['gold_sql'].apply(sqlparse.split)
    df = df.apply(lambda x: process_current_date(x, sql_column), axis=1)
    return df


def get_exec_score(pre_sql, gold_sql, database):
    if any(['SELECT * FROM fake_table'.lower() in itm.lower() for itm in
            gold_sql]) and 'SELECT * FROM fake_table'.lower() in pre_sql.lower():
        return 1
    elif any(['SELECT * FROM fake_table'.lower() in itm.lower() for itm in
              gold_sql]) or 'SELECT * FROM fake_table'.lower() in pre_sql.lower():
        return 0
    else:
        return get_exec_result(database, pre_sql, gold_sql)


def get_database_info(database):
    schema, schema_data = get_schema_and_data(database, 2)
    database_info = ""
    table_info = ""
    for table in schema:
        table_info += table + ": " + ', '.join(schema[table]) + '\n'
    for table_name in schema_data:
        database_info += f"表名'{table_name}'对应的schema和数据：\n"
        database_info += schema_data[table_name]
        database_info += "\n"
    return database_info


def process_sql(sql: str, database):
    sql = sql.replace('CURRENT_DATE', CURRENT_DATE[database])
    sql = sql.replace('current_date', CURRENT_DATE[database])
    sql = sql.replace('NOW()', CURRENT_DATE[database])
    sql = sql.replace('now()', CURRENT_DATE[database])
    sql = sql.replace('CURRENT_TIMESTAMP', CURRENT_DATE[database])
    sql = sql.replace('current_timestamp', CURRENT_DATE[database])
    return sql


def process_current_date(row: pd.Series, column):
    row[column] = process_sql(row[column], row['database'])
    return row


def post_process_sql(model_output):
    # 全体大写
    if "则回复：\"抱歉，无法生成\"::" in model_output:
        # print("err", model_output,flush=True)
        model_output = model_output.split("则回复：\"抱歉，无法生成\"::")[1]
        print("err", model_output)

    if "则回复：\"抱歉，无法生成\":" in model_output:
        # print("err", model_output,flush=True)
        model_output = model_output.split("则回复：\"抱歉，无法生成\":")[1]
        print("err", model_output)

    model_output_temp = model_output.upper()
    if "SELECT" not in model_output_temp:
        return "SELECT * FROM fake_table;"
    else:
        # 分裂
        model_output = model_output[model_output_temp.index("SELECT"):]
    # if '\\"' in model_output:
    #    model_output=model_output.replace('\\"','"')
    if '</s>' in model_output:
        model_output = model_output.replace('</s>', '')
    if '<|endoftext|>' in model_output:
        model_output = model_output.replace('<|endoftext|>', '')

    if 'ORDER BY RANDOM()' in model_output or 'ORDER BY RANDOM()'.lower() in model_output:
        model_output = model_output.replace('ORDER BY RANDOM()', '')
        model_output = model_output.replace('ORDER BY RANDOM()'.lower(), '')
    if model_output[-1] != ";":
        model_output += ";"
    # print(model_output)
    return model_output


def column_exec_eval(dir_name, filename, benchmarks_df):
    if filename.endswith(".json"):
        data_df = pd.DataFrame(json.load(open(os.path.join(dir_name, filename), 'r', encoding='utf-8')))
    elif filename.endswith(".jsonl"):
        # jsonl转为pandas
        data_df = pd.read_json(os.path.join(dir_name, filename), lines=True)
    else:
        print(f"{filename}'s format error,skip ", flush=True)
        return

    data_df = data_df.drop_duplicates(subset=['question'])
    eval_column = filename.split('.json')[0]
    # data_df["database"] = data_df['context'].apply(process_database)
    # data_df["schema"] = data_df['database'].apply(get_database_info)
    # benchmarks_df[eval_column] = data_df["generate"].apply(post_process_sql)
    data_df = data_df.rename(columns={'generate': eval_column})

    # if eval_column in benchmarks_df:
    #    benchmarks_df.drop(eval_column, axis=1)
    #    benchmarks_df.drop(f'{eval_column}_exec_eval', axis=1)

    data_df[eval_column] = data_df[eval_column].apply(post_process_sql)
    columns = data_df.columns.values.tolist()
    for column in columns:
        if column not in ['question', eval_column]:
            data_df = data_df.drop(column, axis=1)

    benchmarks_df = pd.merge(benchmarks_df, data_df, how='left', on='question')
    # benchmarks_df[f'{eval_column}']=data_df[eval_column]

    new_column = f'{eval_column}_exec_eval'

    # if eval_column in benchmarks_df:
    #    benchmarks_df.drop(eval_column, axis=1)
    #    benchmarks_df.drop(f'{eval_column}_exec_eval', axis=1)

    benchmarks_df = post_process(benchmarks_df, eval_column)
    exec_score = []
    print(f'process {eval_column}', flush=True)
    for _, row in benchmarks_df.iterrows():
        exec_score.append(get_exec_score(row[eval_column], row['gold_sql'], row['database']))
    benchmarks_df[new_column] = exec_score
    return benchmarks_df[[eval_column, new_column]]


def post_process_gold_sql(gold_sql):
    if 'ORDER BY RANDOM()' in gold_sql or 'ORDER BY RANDOM()'.lower() in gold_sql:
        gold_sql = gold_sql.replace('ORDER BY RANDOM()', '')
        gold_sql = gold_sql.replace('ORDER BY RANDOM()'.lower(), '')
    if gold_sql[-1] != ";":
        gold_sql += ";"
    return gold_sql


def multi_process(dir_name, benchmarks_df: pd.DataFrame, processNum):
    eval_columns = []
    # 多进程evaluate每个result文件
    from multiprocessing import Pool
    pool, pool_result = Pool(processNum), []
    for file in os.listdir(dir_name):
        if file.endswith(".json") or file.endswith(".jsonl"):
            eval_column = file.split('.json')[0]
            eval_columns.append(eval_column)
            pool_result.append(pool.apply_async(column_exec_eval, args=(dir_name, file, benchmarks_df)))
    pool.close()
    pool.join()
    result_df_list = [r.get() for r in pool_result]
    benchmarks_df = pd.concat([benchmarks_df, *result_df_list], axis=1)
    return eval_columns, benchmarks_df


def single_process(dir_name, benchmarks_df):
    eval_columns = []
    for file in os.listdir(dir_name):
        if file.endswith(".json") or file.endswith(".jsonl"):
            eval_column = file.split('.json')[0]
            eval_columns.append(eval_column)
            result = column_exec_eval(dir_name, file, benchmarks_df)
            benchmarks_df = pd.concat([benchmarks_df, result], axis=1)
    return eval_columns, benchmarks_df


CURRENT_DATE = {
    '超市': "date('2020-12-01')",
    '合同': "date('2023-02-01')",
    '有数bi': "date('2023-04-22')"
}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-ben', '--benchmarks', dest='benchmarks', default="1212_test_benchmarks_new.xlsx", help="gold file")
    parser.add_argument('-dir', '--result_dir', dest='result_dir', default="codellama_v7_4_6_predict_trans", help="result_dir")
    args = parser.parse_args()
    dir_name = args.result_dir
    total_dict = {}
    benchmarks_df = pd.read_excel(args.benchmarks)

    # eval_columns, benchmarks_df = single_process(dir_name, benchmarks_df)
    eval_columns, benchmarks_df = multi_process(dir_name, benchmarks_df, processNum=32)

    for eval_column in eval_columns:
        #  print(total_dict)
        total_dict[eval_column] = eval_model(benchmarks_df, eval_column)
    # total_dict = dict(sorted(total_dict.items(), key=lambda item:float(item[1]['全部结果']), reverse=True))
    total_dict = dict(
        sorted(total_dict.items(), key=lambda item: float(item[1]['sql结果'].split("：")[1]), reverse=True))
    for k, v in total_dict.items():
        print(k, v)
    benchmarks_df.to_excel("exec_result" + args.benchmarks, index=False)
    # pd.DataFrame(total_dict).T.to_excel(os.path.join('result', "test_evals.xlsx"), index=True)
