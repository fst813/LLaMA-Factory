import psycopg2
import os
from tqdm import tqdm
import argparse
import pandas as pd
import random


def get_pgsql_curor(db):
    # 创建PostgreSQL数据库
    conn_pgsql = psycopg2.connect(
        host=args.host,
        # database=f"{db}",
        user="postgres",
        password=args.password
    )
    conn_pgsql.set_session(autocommit=True)
    cur_pgsql = conn_pgsql.cursor()
    sql = f"SELECT datname FROM pg_database WHERE datname='{db.lower()}'"
    cur_pgsql.execute(sql)
    result = cur_pgsql.fetchall()
    if not result:
        cur_pgsql.execute(f'CREATE DATABASE "{db.lower()}"')
    else:
        cur_pgsql.execute(f'DROP DATABASE "{db.lower()}"')
        cur_pgsql.execute(f'CREATE DATABASE "{db.lower()}"')

    conn_pgsql = psycopg2.connect(
        host=args.host,
        database=f"{db.lower()}",
        user="postgres",
        password=args.password
    )
    return conn_pgsql, conn_pgsql.cursor()


def process_quote(text):
    if "'" in text:
        text = text.replace("'", "''")
    return text


def construct_database(db_path, db):
    # 连接pgsql数据库
    conn_pgsql, cur_pgsql = get_pgsql_curor(db)

    # 获取SQLite表的结构信息    
    for filename in os.listdir(db_path):
        df = pd.read_excel(os.path.join(db_path, filename))
        integer_columns = [col for col in df.columns if col.endswith('integer')]
        df[integer_columns] = df[integer_columns].fillna(0).astype(int)
        # float_columns = [col for col in df.columns if col.endswith('float')]
        # df[float_columns] = df[float_columns].fillna(0).astype(float)
        real_columns = [col for col in df.columns if col.endswith('real')]
        df[real_columns] = df[real_columns].fillna(0.0)
        timestamp_columns = [col for col in df.columns if col.endswith('timestamp')]
        time_arr = [f"{i}-01-01 00:00:00" for i in range(1990, 2024)]
        random_idx = random.randint(0, len(time_arr))
        df[timestamp_columns] = df[timestamp_columns].fillna(time_arr[random_idx])
        date_columns = [col for col in df.columns if col.endswith('date')]
        time_arr = [f"{i}-01-01" for i in range(1990, 2024)]
        random_idx = random.randint(0, len(time_arr)-1)
        df[date_columns] = df[date_columns].fillna(time_arr[random_idx])
        bool_columns = [col for col in df.columns if col.endswith('bool')]
        df[bool_columns] = df[bool_columns].fillna(False)
        table = filename.split('.')[0]
        columns = df.columns.values.tolist()
        column_arr = []
        for column in columns:
            field, Type = column.split(':')
            column_arr.append(f'"{field}" {Type}')
        create_table_sql = f'CREATE TABLE "{table}" ({",".join(column_arr)})'
        cur_pgsql.execute(create_table_sql)
        conn_pgsql.commit()
        for _, row in tqdm(df.iterrows(), total=len(df)):
            data_arr = [f"'{process_quote(str(row[key]))}'" for key in columns]
            insert_value_sql = f'insert into "{table}" values({",".join(data_arr)});'
            cur_pgsql.execute(insert_value_sql)
            conn_pgsql.commit()

    cur_pgsql.close()
    conn_pgsql.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default="127.0.0.1", help="pgsql host")
    parser.add_argument('--password', default="postgres", help="pgsql password")
    args = parser.parse_args()
    data_path = r"eval_data"
    for db in os.listdir(data_path):
        db_path = os.path.join(data_path, db)
        construct_database(db_path, db)
