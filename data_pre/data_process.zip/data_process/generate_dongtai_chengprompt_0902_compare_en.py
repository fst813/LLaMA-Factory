'''
1、默认每个members填充10-0（有的情况下，没有就是None）个（只针对text），数据类bool 各2个看下样式。（去重后的）
2、某个字段token 超过30个，（最多填充2个这样的）
3、总长度不超过1800个token

删除方式：
10,8,2,0个members
0个还不满足，则略过本条数据
'''
import json
import os
import random
import logging
from transformers import AutoTokenizer,LlamaTokenizer

from transformers import AutoTokenizer,LlamaTokenizer
#tokenizer = LlamaTokenizer.from_pretrained("D:/2023works\downloads_models\chatYuyan-1.1.0")
#tokenizer = LlamaTokenizer.from_pretrained("/data0/down_models/chatYuyan-1.1.0")
tokenizer_path = "/data1/download_models/codellama-13b-Instruct"
tokenizer = LlamaTokenizer.from_pretrained(tokenizer_path)
need_type = ["text"]


# 计算每个value和question的相似度
import difflib

def get_sorted_members_list(table_column_members,question):
    # 获取公共子序列
    
    # 保存每个value和question的相似度,2*公共子序列长度/（value长度+question长度）
    sorted_members_list = []
    for value in table_column_members:
        # print(value,question)
        # print(difflib.SequenceMatcher(None, value, question).ratio())
        sorted_members_list.append((value,difflib.SequenceMatcher(None, value, question).ratio()))
    # 排序
    sorted_members_list = sorted(sorted_members_list,key=lambda x:x[1],reverse=True)


    
    return sorted_members_list



def get_token_length(text):
    inputs_ids = tokenizer(text, return_tensors="pt")["input_ids"]
    # 获取长度
    current_length = inputs_ids.shape[1]
    return current_length

def get_k_data_example(table_data:list,k,column_index,dataType,question):
    # 样式：去重后，临高;秦皇岛市经济技术开发区
    current_index_data = []
    for item in table_data:
        if item[column_index] not in current_index_data:
            # 字符类型如果长度大于30,取前30个
            if dataType == "text" and get_token_length(item[column_index]) > 30:
                item[column_index] = item[column_index][:30]
            current_index_data.append(item[column_index])
    # 排序
    if dataType == "text":
        current_index_data_score = get_sorted_members_list(current_index_data,question)
        # print(question)
        # print(current_index_data_score)
        # exit()
        current_index_data = [i[0] for i in current_index_data_score]
    


    if len(current_index_data) > k:
        current_index_data = current_index_data[:k]
    return current_index_data



def get_schema_with_data(data,number):
    # 存着备用，删除使用
    table_column_members = {}

    schema_prompt_pre = "Schema and data examples for the table '{table_name}': \n"
    schema_prompt_pre += "| Field Name | Field Type | Field Value Example |\n|-|-|-|\n"
    schema_prompt = ""
    #print(len(data["schema"].keys()),data["schema"].keys())

    for table_name in data["schema"]:

        if table_name not in table_column_members:
            table_column_members[table_name] = {}

        schema_prompt += schema_prompt_pre.format(table_name=table_name)
        #schema_prompt +=
        column_index = 0

        
        items = []
        if isinstance(data["schema"][table_name], dict):
            items = data["schema"][table_name].items()
            print("dict schema")
        else:
            items = data["schema"][table_name]


        #for item in data["schema"][table_name]:
        for item in items:
            #print(item)
            if len(item) != 2:
                print(table_name,item)
            column_name = item[0]
            column_type = item[1]


            k_data_example = get_k_data_example(data["schema_data"][table_name],number,column_index,column_type,data["question"])

            if column_type not in need_type:
                # 非text类型，2个
                k_data_example = k_data_example[:2]
                schema_prompt += "|"+str(column_name) + "|" + str(column_type) + "|"+json.dumps(k_data_example,ensure_ascii=False).strip("[]")+"|\n"
                table_column_members[table_name][column_name] = (column_type,k_data_example)
            else:
                schema_prompt += "|"+str(column_name) + "|" + str(column_type) + "|"+json.dumps(k_data_example,ensure_ascii=False).strip("[]")+"|\n"
                table_column_members[table_name][column_name] = (column_type,k_data_example)
            column_index += 1
        schema_prompt += "\n"

    return schema_prompt,table_column_members


def get_first_prompt(json_data,data_number):
    # 第一次生成
    data_schema_prompt,table_column_members = get_schema_with_data(json_data,number=data_number)
    pre_prompt = "You are an SQL expert, and your task is to answer the user's questions using SQL statements based on the table information.\n\n"
    #pre_prompt += ""
    # pre_prompt = pre_prompt + get_schema_with_data(json_data,number=data_number) + "\n"
    pre_prompt += data_schema_prompt+"\n"
    #pre_prompt = pre_prompt + get_schema_with_data(json_data) + "\n"
    
    #pre_prompt += "同环比用TS_COMPARE(\"同环比字段\", '同比或环比', '时间间隔', \"日期字段\")表示\n"
    pre_prompt += "Requirement:\n同环比用TS_COMPARE(\"同环比字段\", '时间间隔', '同比或环比', \"日期字段\")表示\n\n"

    if "evidence" in json_data:
        # 随机数大于0.5，放前面
        if random.random() > 0.5:
            pre_prompt += "用户问题: " + json_data["evidence"]+ "，"+json_data["question"]+ "\n\n"
        else:
            pre_prompt += "用户问题: " + json_data["question"] +"，"+json_data["evidence"] + "\n\n"
    else:
        pre_prompt += "用户问题: " + json_data["question"] + "\n\n"
    pre_prompt += "Please determine if it is possible to generate SQL. If possible, provide the SQL statement. If not, reply with 'Sorry, unable to generate'."
    return pre_prompt,table_column_members







def get_removed_prompt(table_column_members,json_data,data_number,max_length=1750):

    # 留300给用户问题和instruction
    max_length = max_length - 300 

    flag = 1 #是否保存本条数据
    # 去掉其他字符 占 50个token，剩下的数据字段占 1750个token，删到1750个token
    #pre_prompt = "指令: Create a SQL query for the following question.\n"
    pre_prompt = "你是一个SQL专家，你的任务是根据表格信息，用SQL语句回答用户的问题。\n\n"
    removed_schema_prompt = ""
    number = data_number
    while True:
        #以text类型字段长度 member,保留10->0直到总长度不超过1750个token
        #都为空还超过长度，丢掉数据
        #print(table_column_members)
        data_prompt = get_limte_members_prompt(table_column_members,number)
        #print(data_prompt)
        data_len = get_token_length(data_prompt)
        #print(data_len)
        if data_len <= max_length:
            removed_schema_prompt = data_prompt
            break
        
        if number == 0:
            flag = 0
            break
        number -= 1
    if flag == 0:
        # 数据为空了也不满足
        return ""
    else:
        pre_prompt += removed_schema_prompt+"\n"
        
        # 同环比prompt
        pre_prompt += "要求：\n同环比用TS_COMPARE(\"同环比字段\", '时间间隔', '同比或环比', \"日期字段\")表示\n\n"
        #pre_prompt += "同环比用TS_COMPARE(\"同环比字段\", '同比或环比', '时间间隔', \"日期字段\")表示\n"
        
        if "evidence" in json_data:
        # 随机数大于0.5，放前面
            if random.random() > 0.5:
                pre_prompt += "用户问题: "+ json_data["evidence"]+"，"+json_data["question"]+ "\n\n"
            else:
                pre_prompt += "用户问题: " + json_data["question"] +"，"+json_data["evidence"] + "\n\n"
        else:
             
            pre_prompt += "用户问题: " + json_data["question"] + "\n\n"

        pre_prompt += "请判断能否生成SQL，如果可以则写出SQL，如果不行，则回复：\"抱歉，无法生成\": \n"
        return pre_prompt


def get_limte_members_prompt(table_column_members,number):
    removed_schema_prompt = ""
    for table_name in table_column_members:
        removed_schema_prompt += "表名\'{table_name}\'对应的schema和数据示例: \n".format(table_name=table_name)
        removed_schema_prompt += "|字段名|字段类型|字段值示例|\n|-|-|-|\n"
        for column_name in table_column_members[table_name]:
            column_type, column_members = table_column_members[table_name][column_name]
            if column_type not in need_type:
                removed_schema_prompt += "|"+str(column_name) + "|" + str(column_type) + "|"+json.dumps(column_members,ensure_ascii=False).strip("[]")+"|\n"
            else:
                removed_schema_prompt += "|"+str(column_name) + "|" + str(column_type) + "|"+json.dumps(column_members[:number],ensure_ascii=False).strip("[]")+"|\n"
        removed_schema_prompt += "\n"
    return removed_schema_prompt






def get_right_lenth_prompt(json_data,data_number=10,max_length=1800):
    # 获取第一次生成的长度

    first_prompt,table_column_members =  get_first_prompt(json_data,data_number)
    # 获取长度
    current_length = get_token_length(first_prompt)
    # 如果长度小于1800，直接返回
    if current_length <= max_length:
        # print(first_prompt)
        return first_prompt
    # 如果长度大于1800，删除text类型字段，直到长度小于1800
    else:
        return get_removed_prompt(table_column_members,json_data,data_number-1,max_length)


def process_file_debug(func, data,data_number=10,max_length=1800):
    try:
        answer = func(data,data_number,max_length)
        return answer
    except Exception as e:
        logging.exception(e)
# 进度条包
import tqdm
import json
import numpy as np
from multiprocessing import Pool
def main(input_file,out_file,num_threads=32):
    total_data = []
    with open(input_file,encoding="utf-8") as f:
            lines = f.readlines()

            # 多线程处理
            # 使用tqdm进度条
            pool_result = []
            pool = Pool(num_threads)
            for json_data in tqdm.tqdm(lines):
                data = json.loads(json_data.strip())
                # 最大是6个，长度1700
                out_put = data["final_sql"]
                if  "fake_table" in out_put.lower():
                    out_put = "抱歉，无法生成"
                
                prompt_result = pool.apply_async(process_file_debug, args=(get_right_lenth_prompt, data,3,3500))
                pool_result.append((prompt_result,out_put,data["question"]))


                #pool_result.append(prompt)
            pool.close()
            pool.join()
            for prompt in pool_result:
                item = prompt[0].get()
                if item != "":
                    total_data.append({"instruction": item, "input": "", "output": prompt[1],"question":prompt[2]})
            print("total_data: ", len(total_data))

            # print("total_data: ", len(total_data))

            # for line in tqdm.tqdm(lines):
            #     data = json.loads(line.strip())
            #     prompt = get_right_lenth_prompt(data,10,1800)
            #     if len(prompt) > 0:
            #         print(prompt)
            #         # 需要生成
            #         target = data["pred_sql"]
            #         total_data.append({"instruction": prompt, "input": "", "output": target,"question":data["question"]})
            # print("total_data: ", len(total_data))
    print(total_data[-1]["instruction"])
    print(total_data[-1]["output"])
            # # print("1")

    # 打乱顺序
    random.shuffle(total_data)


    with open(out_file,"w",encoding="utf-8") as f2:
        f2.write(json.dumps(total_data, indent=4, ensure_ascii=False))

if __name__ == '__main__':
    import sys
    input_file = sys.argv[1]
    out_file = sys.argv[2]
    
    # # input_file = "./1_full_v5_final.jsonl"
    # # out_file = "./total_gpt4_v5_30w_prompt_dynamic_nofx_6_1700.json"
    main(input_file,out_file)
    # value = "abcde"
    # question = "acde"
    # result = difflib.SequenceMatcher(None, value, question).ratio()
    
    # print(result)
    #matched_string = value[result.a: result.a + result.size]
    #print(matched_string)
