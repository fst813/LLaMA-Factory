import json
import random
random.seed(3)
from tqdm import tqdm
from transformers import AutoTokenizer, CodeLlamaTokenizer

# 读取json文件
def read_json(file):
    with open(file, 'r', encoding="utf-8") as f:
        data = json.load(f)
    return data


def process_mul(data_item):
    item, all_table, tokenizer = data_item
    prompt = item["instruction"]
    exist_table = set()
    tables = prompt.split("\n\n表名")[1:]
    for table in tables:
        table = table.split("\n\n\n要求")[0]
        exist_table.add(table)
    # all_table中删除已经存在的表
    for table in exist_table:
        if table in all_table:
            all_table.remove(table)
    random_num = random.random()
    input_ids = tokenizer.encode(prompt, return_tensors="pt", add_special_tokens=False)
    raw_len = len(input_ids[0])
    add_len = len(input_ids[0])
    if len(input_ids[0]) >= 1000:
        return item, len(input_ids[0]), raw_len
    if len(input_ids[0]) < 1000 and random_num > 0.2:
        return item, len(input_ids[0]), raw_len
    while True:
        input_ids = tokenizer.encode(prompt, return_tensors="pt", add_special_tokens=False)
        if len(input_ids[0]) < 3500:
            # 随机选择一个表
            if len(all_table) == 0:
                add_len = len(input_ids[0])
                break
            random_table = all_table[random.randint(0, len(all_table) - 1)]
            prompt_table = prompt.split("\n\n\n要求")[0]
            prompt_post = prompt.split("\n\n\n要求")[1]
            prompt_1 = prompt_table + "\n\n表名" + random_table + "\n\n\n要求" + prompt_post
            input_ids = tokenizer.encode(prompt_1, return_tensors="pt", add_special_tokens=False)
            #random_table = all_table[random.randint(0, len(all_table) - 1)]
            #prompt_table = prompt.split("\n\n\n用户问题")[0]
            #prompt_post = prompt.split("\n\n\n用户问题")[1]
            #prompt_1 = prompt_table + "\n\n表名" + random_table + "\n\n\n用户问题" + prompt_post
            #input_ids = tokenizer.encode(prompt_1, return_tensors="pt", add_special_tokens=False)
            if len(input_ids[0]) > 3500:
                add_len = len(input_ids[0])
                break
            else:
                prompt = prompt_1
        else:
            add_len = len(input_ids[0])
            break
    item["instruction"] = prompt
    return item, add_len, raw_len


if __name__ == '__main__':
    import sys
    input_data = sys.argv[1]
    output_data = sys.argv[2]

    #input_data = "spider_dev_input_prompt_new.json"
    #input_data = "/data1/all_data/gpt_v7.3_compare/v7.3_1027_32w_nofx_3_3500_llamatoken_fix.json"
    #output_data = "spider_dev_input_prompt_new_addtable.json"
    #model_path = "/data1/download_models/CodeLlama-13b-Instruct-hf"
    model_path = "/data/fst/download_models/Meta-Llama-3-8B-Instruct/"
    #tokenizer = CodeLlamaTokenizer.from_pretrained(model_path)
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    data = read_json(input_data)
    # data = data[:300]
    print(len(data))
    # data = data[:100]
    all_table = []
    for item_1 in data:
        instruction = item_1["instruction"]

        tables = instruction.split("\n\n表名")[1:]
        for table in tables:
            table = table.split("\n\n\n要求")[0]
            all_table.append(table)
    print(len(all_table))
    all_table = list(set(all_table))
    import multiprocessing as mp

    pool = mp.Pool(processes=32)
    data_item = [(item, all_table, tokenizer) for item in tqdm(data)]
    result_final = pool.map(process_mul, data_item)
    pool.close()
    pool.join()
    print(len(result_final))
    data_final = [item[0] for item in result_final]
    add_table_len = [item[1] for item in result_final]
    raw_len = [item[2] for item in result_final]

    # 统计加表前后的长度，在0-1000、1000-2000、2000-3000、3000-3500的分布
    data_analyze = {"less_1000": 0, "less_2000": 0, "less_3000": 0, "less_3500": 0}
    data_analyze_noadd = {"less_1000": 0, "less_2000": 0, "less_3000": 0, "less_3500": 0}
    for i in range(len(raw_len)):
        if raw_len[i] < 1000:
            data_analyze_noadd["less_1000"] = data_analyze_noadd.get("less_1000", 0) + 1
        elif raw_len[i] < 2000:
            data_analyze_noadd["less_2000"] = data_analyze_noadd.get("less_2000", 0) + 1
        elif raw_len[i] < 3000:
            data_analyze_noadd["less_3000"] = data_analyze_noadd.get("less_3000", 0) + 1
        elif raw_len[i] < 3500:
            data_analyze_noadd["less_3500"] = data_analyze_noadd.get("less_3500", 0) + 1
    for i in range(len(add_table_len)):
        if add_table_len[i] < 1000:
            data_analyze["less_1000"] = data_analyze.get("less_1000", 0) + 1
        elif add_table_len[i] < 2000:
            data_analyze["less_2000"] = data_analyze.get("less_2000", 0) + 1
        elif add_table_len[i] < 3000:
            data_analyze["less_3000"] = data_analyze.get("less_3000", 0) + 1
        else:
            data_analyze["less_3500"] = data_analyze.get("less_3500", 0) + 1
    print("小于1000的个数，raw:", data_analyze_noadd["less_1000"], "add:", data_analyze["less_1000"])
    print("小于2000的个数，raw:", data_analyze_noadd["less_2000"], "add:", data_analyze["less_2000"])
    print("小于3000的个数，raw:", data_analyze_noadd["less_3000"], "add:", data_analyze["less_3000"])
    print("小于3500的个数，raw:", data_analyze_noadd["less_3500"], "add:", data_analyze["less_3500"])
    #print(add_table_len)
    #print(raw_len)
    with open(output_data, "w", encoding="utf-8") as f:
        json.dump(data_final, f, ensure_ascii=False, indent=4)



