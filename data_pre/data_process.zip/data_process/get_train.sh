# base_path=./gpt_1222_v7.4.3_fix
base_path=./gpt_v7.4.4

python generate_dongtai_chengprompt_0902_compare_juhe.py  ${base_path}/base_v_7_4_4.jsonl ${base_path}/base_v_7_4_4_32w_nofx_3_3500_llamatoken_prompt_id.json
python add_table.py ${base_path}/v7.4.3_fix_1229_32w_nofx_3_3500_llamatoken_prompt_id.json ${base_path}/v7.4.3_fix_1229_32w_nofx_3_3500_llamatoken_prompt_id_addtable.json
python get_fx_prompt.py ${base_path}/v7.4.3_fix_1229_32w_nofx_3_3500_llamatoken_prompt_id.json ${base_path}/v7.4.3_fix_1229_32w_codellama_3_3500_llamatoken_prompt_id.json
python get_fx_prompt.py ${base_path}/v7.4.3_fix_1229_32w_nofx_3_3500_llamatoken_prompt_id_addtable.json ${base_path}/v7.4.3_fix_1229_32w_codellama_3_3500_llamatoken_prompt_id_addtable2.json
