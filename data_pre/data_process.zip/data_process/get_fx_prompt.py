# coding=utf-8
import random
random.seed(3)
# {"text":"玉言（Yuyan）是由网易伏羲实验室开发的人工智能聊天助手。下面是一段玉言和用户之间的对话：\n<|Human|>:\n请定义虚荣和傲慢之间的区别。\n\n<|Yuyan|>:\n傲慢和虚荣的区别在于，傲慢是指过度的自豪或傲慢，而虚荣则是指那些虚荣、徒劳或毫无价值的东西；那些没有价值、用处或收益的东西。<\/s>\n\n<|Human|>:\n你知道这些词的同义词吗？\n\n<|Yuyan|>:\n当然！这里有一些傲慢和虚荣的同义词。对于傲慢：傲慢、自负和自大。对于虚荣：自恋、自我陶醉和自夸。这些只是这些词的一些同义词。如果你需要更多，使用一本同义词词典是了解这些词的好方法。<\/s>"}

# #    {
#         "instruction": "指令: Create a SQL query for the following question.\n表名'Family'对应的schema: \nid(integer), name(text), gender(text), birth_date(date), relation(text), occupation(text), nationality(text), phone_number(text), email(text), address(text), family_role(text)\n表名'Social_Network'对应的schema: \nid(integer), name(text), gender(text), birth_date(text), occupation(text), nationality(text), phone_number(text), email(text), address(text), friend_name(text), friend_relation(text), friend_contact(text), last_meeting(text)\n\n用户问题: John Smith和Bob Johnson的关系是什么？\n请判断能否生成SQL，如果可以则写出SQL，如果不行，则回复：\"抱歉，无法生成\": \n",
#         "input": "",
#         "output": "SELECT friend_relation FROM Social_Network WHERE (name='John Smith' AND friend_name='Bob Johnson') OR (name='Bob Johnson' AND friend_name='John Smith')",
#         "question": "John Smith和Bob Johnson的关系是什么？"
#     },
import json
def merge_two_jsonl(filename1,filename2,save_filename):
    with open(filename1, encoding="utf-8") as f:
        with open(filename2, encoding="utf-8") as f2:
            with open(save_filename, "w", encoding="utf-8") as f3:
                for line in f:
                    f3.write(line)
                for line in f2:
                    f3.write(line)
    



def get_fx_formate(instruction:str,question:str,output:str):
    result = {}
    #fx_instruction,post_question = instruction.split("用户问题:")
    

    fx_question = "<|Human|>:\n"+instruction+"\n\n<|Yuyan|>:\n"
    result["instruction"] = fx_question
    result["input"] = ""
    result["output"] = output
    result["question"] = question
    return result

def get_vicuna_formate(instruction:str,question:str,output:str):
    result = {}
    #fx_instruction,post_question = instruction.split("用户问题:")
    
    #vicuna_question = "User:{input}\n\nAssistant:".format(input=instruction)
    codellama_question = "{input}".format(input=instruction)
    #Platypus_question = "### Instruction:\n{instruction}\n\n### Response:".format(instruction=instruction)
    #zephyr_question = "<System>You are an AI, called ChatAI.</System>\n<User>{input}</User>\n<Assistant>".format(input=instruction)
    #result["instruction"] = vicuna_question
    result["instruction"] = codellama_question
    #result["instruction"] = zephyr_question

    result["input"] = ""
    result["output"] = output
    result["question"] = question
    return result


def get_fx_test_formate(instruction:str,question:str,output:str):
    result = {}
    #fx_instruction,post_question = instruction.split("用户问题:")
    
    #Platypus_question = "### Instruction:\n{instruction}\n\n### Response:".format(instruction=instruction)
    #result["context"] = Platypus_question
    #vicuna_question = "User:{input}\n\nAssistant:".format(input=instruction)
    #codellama_question = "[INST]{input}[/INST]".format(input=instruction)
    zephyr_question = "<System>You are an AI, called ChatAI.</System>\n<User>{input}</User>\n<Assistant>".format(input=instruction)
    #result["context"] = codellama_question
    result["context"] = zephyr_question
    #fx_question = "<|Human|>:\n"+instruction+"\n\n<|Yuyan|>:\n"
    #result["context"] = vicuna_question
    #result["input"] = ""
    result["target"] = output
    result["question"] = question
    return result


def chang_format(filename,save_filename):
    total = []
    with open(filename, encoding="utf-8") as f:
        with open(save_filename, "w", encoding="utf-8") as f2:
            data = json.load(f)
            for line in data:
                fx_formate = get_fx_formate(line["instruction"],line["question"],line["output"])
                total.append(fx_formate)
            # 打乱
            random.shuffle(total)
            print(len(total))
            print(total[0]["instruction"])
            print(total[0]["output"])
            json.dump(total,f2,ensure_ascii=False,indent=4)


def chang_vicuna_format(filename,save_filename):
    total = []
    with open(filename, encoding="utf-8") as f:
        with open(save_filename, "w", encoding="utf-8") as f2:
            data = json.load(f)
            for line in data:
                fx_formate = get_vicuna_formate(line["instruction"],line["question"],line["output"])
                fx_formate["uuid"] = line["uuid"]
                fx_formate["timestamp"] = line["timestamp"]
                total.append(fx_formate)
            # 打乱
            random.shuffle(total)
            print(len(total))
            print(total[0]["instruction"])
            print(total[0]["output"])
            json.dump(total,f2,ensure_ascii=False,indent=4)

def chang_test_format(filename,save_filename):
    total = []
    with open(filename, encoding="utf-8") as f:
        with open(save_filename, "w", encoding="utf-8") as f2:
            
            for line in f:
                line = json.loads(line)
                fx_formate = get_fx_test_formate(line["context"],line["question"],line["target"])
                total.append(fx_formate)
            # 打乱
            #random.shuffle(total)
            print(len(total))
            print(total[0]["context"])
            print(total[0]["target"])
            for item in total:
                f2.write(json.dumps(item,ensure_ascii=False)+"\n")




if __name__ == '__main__':
    import sys
    f1 = sys.argv[1]
    f2 = sys.argv[2]

    # merge_two_jsonl("data_ori_kxiao\\train.jsonl","data_ori_kxiao\\dev.jsonl","data_ori_kxiao\\train_dev.jsonl")
    # chang_format("data_ori_kxiao/v5_origin/35_w2/total_35w_v3_bool_huang_0.8.json","data_ori_kxiao/v5_origin/35_w2/total_35w_v3_bool_fx2_0.8.json")
    # chang_test_format("data_ori_kxiao/test_data/0526_test_huang.jsonl","data_ori_kxiao/test_data/0526_test_fuxi2.jsonl")
    # 测试集
    #chang_test_format(f1,f2)
    # 训练集
    chang_vicuna_format(f1,f2)
    #chang_format(f1,f2)
    #chang_format("./total_gpt4_v5_30w_prompt_dynamic_nofx_6_1700.json","./total_gpt4_v5_30w_prompt_dynamic_fx_6_1700.json")
    #data_ori_kxiao\test_data\0526_test_huang.jsonl
    #chang_format("data_ori_kxiao\\test.jsonl","data_ori_kxiao\\test_fx.jsonl")
