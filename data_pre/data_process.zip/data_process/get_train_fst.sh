base_path=./gptllama3_v7.10.0
#data_name=base_v_7_9_0
data_name=fenzupaixu
python generate_dongtai_chengprompt_0902_compare_juhe.py  ${base_path}/${data_name}.jsonl ${base_path}/${data_name}_3500.json
python add_table.py ${base_path}/${data_name}_3500.json ${base_path}/${data_name}_3500_addtable.json
python get_fx_prompt.py ${base_path}/${data_name}_3500_addtable.json ${base_path}/${data_name}_3500_addtable_prompt.json

