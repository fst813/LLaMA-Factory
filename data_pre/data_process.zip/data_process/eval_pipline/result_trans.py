import json


def read_jsonl(json_file):
    with open(json_file, "r", encoding="utf-8") as f:
        json_list = [json.loads(line.strip()) for line in f.readlines()]
    return json_list

def read_json(json_file):
    with open(json_file, "r", encoding="utf-8") as f:
        json_list = json.load(f)
    return json_list

if __name__ == '__main__':
    from argparse import ArgumentParser

    parser = ArgumentParser()
    parser.add_argument("--raw_test_path", default="/home/fangsongtao/train_frame/LLaMA-Factory/data/v7.4.8_test.json", help="验证集数据")
    parser.add_argument("--predict_path", help="预测生成的sql文件路径")
    # parser.add_argument("--output_path", help="预测生成的sql文件路径")

    args = parser.parse_args()
    # 读取原始测试数据
    raw_test = read_json(args.raw_test_path)
    # 遍历文件夹，找到所有的jsonl文件
    import os
    dir_path = args.predict_path
    #dir_path = "./codellama_hf_bs_1/"
    output_path = dir_path + "_trans"
    #output_path = "./codellama_bs1"
    if not os.path.exists(output_path):
        os.makedirs(output_path)
    file_list = []
    file_all = os.listdir(dir_path)
    for file in file_all:
        if file.endswith(".jsonl") and "checkpoint" in file:
            file_list.append(os.path.join(dir_path, file))
    print(file_list)
    # 读取所有的jsonl文件
    # data_all = []
    for file in file_list:
        data = read_jsonl(file)
        data_epoch = []
        for index, item in enumerate(data):
            item["context"] = raw_test[index]["instruction"]
            item["question"] = raw_test[index]["question"]
            item["target"] = raw_test[index]["output"]
            item["generate"] = item["predict"]
            del item["label"]
            del item["predict"]
            data_epoch.append(item)
        with open(file.replace(".jsonl", ".json"), "w", encoding="utf-8") as f:
            json.dump(data_epoch, f, ensure_ascii=False, indent=4)
        import shutil
        shutil.copy(file.replace(".jsonl", ".json"), output_path)


