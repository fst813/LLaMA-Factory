pwd=$PWD
predict_path="codellama_7_4_9_predict"
predict_path="llama3_8b_v7_4_9_int8_predict"
predict_path="/home/fangsongtao/LLaMA-Factory/llama3_v7_9_0_predict"
python3 result_trans.py --predict_path $predict_path
cp -r "${predict_path}_trans" /home/fangsongtao/eval_pgsql/model_results/
cd /home/fangsongtao/eval_pgsql
python evaluation_4_multianswer.py -ben 1212_test_benchmarks_new.xlsx -dir model_results/"$(basename "$predict_path")_trans"

